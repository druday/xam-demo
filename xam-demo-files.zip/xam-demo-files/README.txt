XAM demo files (everything invented)

These are the files of one invented qualifying-exam day run through XAM by docs/demo/build_demo.py:
the map page after each round (roundN/map.html, as XAM wrote it to disk), the map itself (map.json),
the text view XAM read (map-show.txt), the files the model wrote (model/), the stored review, the page
after the student's own edits (page-edits/), the sealed report, audit.json, transcript, SEAL.txt and the
verify output (sealed/), the whole sealed archive (sealed/archive/), the chat as the hooks saw it (chat/)
and the builder's script (demo_script.json).

The question, the student, the Zotero library (library/papers.json) and the reviews are invented for this
demo. The three examiners are XAM's fictional composites. Reviews are indicative: XAM rated the map, not a
written answer, and no committee graded anything. Paths inside the files name the temporary folder the
build ran in.

The STIR-L4 suggestions (the circles beside each idea) are real PubMed records. PubMed's replies, and the drafts
and judgments of XAM's background helper (Claude Haiku), were recorded on 14 November 2026 and replayed by the
build. The question folder's stir/ holds each idea's result, its drafts and the judgments. The raw PubMed replies
(stir/raw/) are left out of this zip because of their size; the build verified the sealed archive with them in place.
